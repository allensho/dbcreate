#!/bin/bash

DB_NAME="gis_conceptual"
DB_USER="postgres"
DB_HOST="localhost"
DB_PORT="5432"

read -p "gis_conceptual db pass: " PG_PASS 

# Run the database creation script
echo "Dropping database..."
PGPASSWORD=$PG_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_USER -f "C:\Code\cto-gis-lakehouse\cto-gis-lakehouse\scripts\drop_db.sql"

