SELECT pg_terminate_backend(pg_stat_activity.pid) 
FROM pg_stat_activity 
WHERE datname = 'gis_conceptual' AND pid <> pg_backend_pid();

DROP DATABASE gis_conceptual;
