-- SCHEMA: star_schema

DROP SCHEMA IF EXISTS star_schema ;

CREATE SCHEMA IF NOT EXISTS star_schema
    AUTHORIZATION postgres;