-- FUNCTION: star_schema.fnct_get_elevation(geometry, character varying)

-- DROP FUNCTION IF EXISTS star_schema.fnct_get_elevation(geometry, character varying);

CREATE OR REPLACE FUNCTION star_schema.fnct_get_elevation(
	pt geometry,
	units character varying)
    RETURNS numeric
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
	-- Author - Scott Newby
	-- Date - 2025.02.11
	-- Get Elevation via Lambda function
	-- Description -
	-- take a geom, convert to lat/lng, construct json to send to lambda function to 
	-- call usgs elevation service, rip resulting return to elevation based on required units
	DECLARE requestmsg jsonb; slat character varying (36); slng character varying (36); ret numeric;
	BEGIN
		requestmsg = json_build_object(
        'lat', ST_Y(pt),
        'lng', ST_X(pt),
        'units', units
    	);
		WITH lambda_response AS (
	    SELECT * FROM aws_lambda.invoke('lf-gis-poc-update-land-area-elevation', requestmsg)
		)
		select ((payload::jsonb->'body'->>'elevation')::jsonb->'elevation')::numeric into ret FROM lambda_response limit 1;
		return ret;
	END;
$BODY$;

ALTER FUNCTION star_schema.fnct_get_elevation(geometry, character varying)
    OWNER TO postgres;
