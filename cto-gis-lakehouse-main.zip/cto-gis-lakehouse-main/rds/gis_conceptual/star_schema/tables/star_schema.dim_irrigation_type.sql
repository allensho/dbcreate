-- Table: star_schema.dim_irrigation_type

DROP TABLE IF EXISTS star_schema.dim_irrigation_type;

CREATE TABLE IF NOT EXISTS star_schema.dim_irrigation_type
(
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS star_schema.dim_irrigation_type
    OWNER to postgres;