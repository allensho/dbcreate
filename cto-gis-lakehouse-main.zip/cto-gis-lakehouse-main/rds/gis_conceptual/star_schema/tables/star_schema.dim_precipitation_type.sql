-- Table: star_schema.dim_precipitation_type

-- DROP TABLE IF EXISTS star_schema.dim_precipitation_type;

CREATE TABLE IF NOT EXISTS star_schema.dim_precipitation_type
(
    precipitation_type_id serial NOT NULL,
    create_datetime_utc timestamp with time zone NOT NULL DEFAULT timezone('utc'::text, now()),
    last_update_datetime_utc timestamp with time zone,
    preciptiation_type_name character varying(256) COLLATE pg_catalog."default" NOT NULL,
    precipitation_type_description character varying(512) COLLATE pg_catalog."default",
    CONSTRAINT dim_precipitation_type_pkey PRIMARY KEY (precipitation_type_id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS star_schema.dim_precipitation_type
    OWNER to postgres;