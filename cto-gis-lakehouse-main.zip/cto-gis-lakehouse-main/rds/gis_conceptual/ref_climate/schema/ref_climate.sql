-- SCHEMA: ref_climate

DROP SCHEMA IF EXISTS ref_climate ;

CREATE SCHEMA IF NOT EXISTS ref_climate
    AUTHORIZATION postgres;