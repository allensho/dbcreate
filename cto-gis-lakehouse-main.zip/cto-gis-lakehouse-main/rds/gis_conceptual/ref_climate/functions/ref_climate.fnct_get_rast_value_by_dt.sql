-- FUNCTION: ref_climate.fnct_get_rast_value_by_dt(integer, geometry, date)

-- DROP FUNCTION IF EXISTS ref_climate.fnct_get_rast_value_by_dt(integer, geometry, date);

CREATE OR REPLACE FUNCTION ref_climate.fnct_get_rast_value_by_dt(
	ibandnum integer,
	pt geometry,
	dt date)
    RETURNS numeric
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
	BEGIN
		-- skn - 2025.02.13 - 
		-- create function to get raster value by band for a point
		return (select st_value(r.rast, ibandnum, pt) from ref_climate.gpcp_rasters r where r.rast_date = dt and st_intersects(r.rast, pt));
	END;
$BODY$;

ALTER FUNCTION ref_climate.fnct_get_rast_value_by_dt(integer, geometry, date)
    OWNER TO postgres;
