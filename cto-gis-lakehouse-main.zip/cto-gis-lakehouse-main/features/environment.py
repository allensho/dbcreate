import logging
import os
from datetime import datetime


def before_all(context):
    # Ensure the artifacts directory exists
    artifacts_dir = os.path.abspath("artifacts")
    os.makedirs(artifacts_dir, exist_ok=True)
    
    #ts based log file:
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
     # Define full path for the log file
    log_file = os.path.join(artifacts_dir, f"behave_tests_{timestamp}.log")

    # Configure logging
    logging.basicConfig(
        filename=log_file,
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        force=True,  # Ensures no previous log configuration blocks this
    )

    # Create a logger instance
    context.logger = logging.getLogger("behave_logger")
    context.logger.setLevel(logging.INFO)

    # Add console handler for debugging
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    console_handler.setFormatter(formatter)
    context.logger.addHandler(console_handler)

    # Debugging message to confirm logger works
    context.logger.info(f"Logging setup complete. Log file: {log_file}")

def after_scenario(context, scenario):
    if scenario.status == "failed":
        context.logger.error(f"Scenario '{scenario.name}' failed.")
    else:
        context.logger.info(f"Scenario '{scenario.name}' passed.")
