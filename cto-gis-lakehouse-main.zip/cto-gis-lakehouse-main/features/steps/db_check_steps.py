import psycopg2
from behave import given, when, then
import configparser
from common_steps import *

# Initialize configuration
config = configparser.ConfigParser()
config.read('./config.ini')

# Step to connect to the PostgreSQL database
@given('I connect to the PostgreSQL database')
def step_connect_to_database(context):
     #connect to db
    db_connect(context)
    #setup_db(context)

# Step to check if the schema exists
@when('I check for the schema "{schema_name}"')
def step_check_schema(context, schema_name):
    try:
        context.logger.info(f"Database schema check for {schema_name} testing.")
        query = """
        SELECT schema_name
        FROM information_schema.schemata
        WHERE schema_name = %s;
        """
        context.cursor.execute(query, (schema_name,))
        context.schema_exists = context.cursor.fetchone() is not None
        context.logger.info(f"Database schema check for {schema_name} succeeded.")
    except Exception as e:
        context.logger.error(f"Database schema check for {schema_name} failed: {e}")
        raise

# Step to verify that the schema exists
@then('the schema should exist')
def step_schema_should_exist(context):
    assert context.schema_exists, "Schema does not exist in the database."

# Step to check if the table exists in the schema
@when('I check for the table "{table_name}" in the schema "{schema_name}"')
def step_check_table_in_schema(context, table_name, schema_name):
    try:
        context.logger.info(f"Database table check for {schema_name}.{table_name} testing.")
        query = """
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = %s AND table_name = %s;
        """
        context.cursor.execute(query, (schema_name, table_name))
        context.table_exists = context.cursor.fetchone() is not None
        context.logger.info(f"Database table check for {schema_name}.{table_name} succeeded.")
    except Exception as e:
        context.logger.error(f"Database table check for {schema_name}.{table_name} failed: {e}")
        raise

# Step to check if the function exists in the schema
@when('I check for the function "{function_name}" in the schema "{schema_name}"')
def step_check_function_in_schema(context, function_name, schema_name):
    try:
        context.logger.info(f"Database function check for {schema_name}.{function_name} testing.")
        query = """
            SELECT proname
            FROM pg_proc 
            WHERE proname = %s 
        """
        context.cursor.execute(query, (function_name,))
        context.function_exists = context.cursor.fetchone() is not None
        context.logger.info(f"Database function check for {schema_name}.{function_name} succeeded.")
    except Exception as e:
        context.logger.error(f"Database function check for {schema_name}.{function_name} failed: {e}")
        raise

# Step to check if the trigger exists in the schema
@when('I check for the trigger "{trigger_name}" for table "{table_name}"')
def step_check_trigger_in_schema(context, trigger_name, table_name):
    try:
        context.logger.info(f"Database trigger check for {table_name} - {trigger_name} testing.")
        query = """
            SELECT trigger_name
            FROM information_schema.triggers
            WHERE trigger_name = %s and event_object_table = %s;
        """
        context.cursor.execute(query, (trigger_name, table_name))
        context.trigger_exists = context.cursor.fetchone() is not None
        context.logger.info(f"Database function check for {table_name} - {trigger_name} succeeded.")
    except Exception as e:
        context.logger.error(f"Database function check for {table_name} - {trigger_name} failed: {e}")
        raise

# Step to check the record count of a table
@when('I check the record count of the table "{table_name}" in the schema "{schema_name}"')
def step_check_record_count(context, table_name, schema_name):
    try:
        context.logger.info(f"Database record count check for {schema_name}.{table_name} testing.")
        query = f"SELECT COUNT(*) FROM {schema_name}.{table_name};"
        context.cursor.execute(query)
        context.record_count = context.cursor.fetchone()[0]
        context.logger.info(f"Database record count check for {schema_name}.{table_name} succeeded with rec count: {context.record_count}.")
    except Exception as e:
        context.logger.error(f"Database record count check for {schema_name}.{table_name} failed): {e}")
        raise

# Step to verify the record count of a table
@then('the record count should be "{count}"')
def step_verify_record_count(context, count):
    assert context.record_count == int(count), f"Record count is not as expected. Expected: {count}, Actual: {context.record_count}"

# Step to verify that the table exists
@then('the table "{table_name}" should exist')
def step_table_should_exist(context, table_name):
    assert context.table_exists, f"Table {table_name} does not exist in the schema."

# Step to verify that the function exists
@then('the function "{function_name}" should exist')
def step_function_should_exist(context, function_name):
    assert context.function_exists, f"Table {function_name} does not exist in the schema."

# Step to verify that the trigger exists
@then('the trigger "{trigger_name}" should exist')
def step_trigger_should_exist(context, trigger_name):
    assert context.trigger_exists, f"Table {trigger_name} does not exist in the schema."

# Close the connection after the scenario is completed
@then('close the database connection')
def step_close_connection(context):
    # teardown_db(context)
    close_connection(context)
