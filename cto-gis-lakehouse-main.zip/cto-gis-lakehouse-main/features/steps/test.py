from behave import given, when, then

@given('I start a test')
def step_start_test(context):
    context.logger.info("Test execution has started!")
