import psycopg2
import configparser
# Close the connection after the scenario is completed

# Initialize configuration
config = configparser.ConfigParser()
config.read('./config.ini')

def db_connect(context):
    try:
        #connect to db
        context.conn = psycopg2.connect(
            host= config['database']['host'],
            database=config['database']['db'],
            user=config['database']['user'],
            password=config['database']['password']
        )
        context.cursor = context.conn.cursor()
        context.logger.info("Connected successfully.")
    except Exception as e:
        context.logger.error(f"Database connection failed: {e}")
        raise
def close_connection(context):
    context.cursor.close()
    context.conn.close()

# def setup_db(context):
    # # Read the SQL files
    # with open('database\\create\\ref_climate_test.sql', 'r') as file:
    #     sql_schema = file.read()
    # with open('database\\create\\trg_fnct_blob_to_50x50_raster.sql', 'r') as file:
    #     sql_trg = file.read()
    # with open('database\\create\\geotiff_blobs.sql', 'r') as file:
    #     sql_blob = file.read()
    # with open('database\\create\\gpcp_rasters.sql', 'r') as file:
    #     sql_raster = file.read()

    # # Execute the SQL script
    # try:
    #     context.cursor.execute(sql_schema)
    #     context.conn.commit()  # Commit the changes
    #     print("schema executed successfully.")
    #     context.cursor.execute(sql_trg)
    #     context.conn.commit()  # Commit the changes
    #     print("trg executed successfully.")
    #     context.cursor.execute(sql_blob)
    #     context.conn.commit()  # Commit the changes
    #     print("tbl blobs executed successfully.")
    #     context.cursor.execute(sql_raster)
    #     context.conn.commit()  # Commit the changes
    #     print("tbl raster executed successfully.")
    # except Exception as e:
    #     context.conn.rollback()  # Rollback in case of error
    #     print(f"An error occurred: {e}")
    # finally:
    #     # Close the cursor and connection
    #     print(f"finally")
    #     # context.cursor.close()
    #     # context.conn.close()
# def teardown_db(context):
#     # Read the SQL file
#     with open('database\\destroy\\drop_schema.sql', 'r') as file:
#         sql_script = file.read()

#     # Execute the SQL script
#     try:
#         context.cursor.execute(sql_script)
#         context.conn.commit()  # Commit the changes
#         print("SQL script executed successfully.")
#     except Exception as e:
#         context.conn.rollback()  # Rollback in case of error
#         print(f"An error occurred: {e}")
#     finally:
#         # Close the cursor and connection
#         context.cursor.close()
#         context.conn.close()