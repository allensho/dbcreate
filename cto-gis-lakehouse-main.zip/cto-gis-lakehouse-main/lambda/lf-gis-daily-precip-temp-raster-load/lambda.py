import os
import boto3
import requests
from datetime import date, timedelta, datetime
import configparser

config = configparser.ConfigParser()
config.read('config.ini')
# Initialize S3 client
s3 = boto3.client('s3')
#db connection info:

# Define the publicly accessible GCS URL
# TODO - get from config?
# TODO - 'year' proof this by setting current year
GCS_BASE_URL = "https://storage.googleapis.com/noaa-ncei-nclimgrid-daily/cog/2025/"
S3_BUCKET = "landing-zone-stmpnk"
S3_PREFIX = "gis-raw-raster/"

# Get the last raster date 
def get_max_rstr_date():
    # Get the latest raster date from the tracking file in the s3 bucket
    try:
        # Get the file
        response = s3.get_object(Bucket='landing-zone-stmpnk', Key='gis-raw-raster/max_raster_dt.txt')
        # read the response
        file_content = response['Body'].read().decode('utf-8')
    
        return file_content

    except Exception as error:
        print(f"ERROR - get_max_rstr_date failed with {error}")
        raise

def lambda_handler(event, context):
    
    try:
        # get the start_date based on the max raster date in the tracking file in s3 bucket
        start_date = datetime.strptime(get_max_rstr_date(), "%Y-%m-%d").date() + timedelta(days=1)
        # set end date to today
        end_date = date.today()
        # initialize
        filenm = None
        # may not be necessary
        current_date = start_date
        while current_date <= end_date:
            # set the expected file name
            tiff_file = "nclimgrid-daily-" + current_date.strftime("%Y%m%d") + ".tif"
            # Construct the full URL for the TIFF file on GCS
            gcs_url = GCS_BASE_URL + tiff_file
            # print(f"Downloading {tiff_file} from GCS")
            # Download the TIFF file
            response = requests.get(gcs_url)
            # good response - save the file into the bucket
            if response.status_code == 200:
                # Define the target S3 key
                s3_key = S3_PREFIX + tiff_file
                # Upload the file to S3
                s3.put_object(Bucket=S3_BUCKET, Key=s3_key, Body=response.content)
                print(f"PROGRESS - Uploaded {tiff_file} to S3 at {s3_key}")
            else:
                print(f"PROGRESS - Failed to download {tiff_file} from GCS. Status code: {response.status_code}")
            # next day
            current_date += timedelta(days=1)
        print(f"COMPLETED - lg-gis-daily-precip-temp-raster-load - lambda_handler completed")
        return {
            'statusCode': 200,
            'body': f'Successfully uploaded TIFF files to {S3_BUCKET}/{S3_PREFIX}'
            }
    except Exception as error:
        print(f"ERROR - lf-gis-daily-precip-temp-raster-load - lambda_handler failed with {error}")
        raise
        
