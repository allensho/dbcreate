import json
import os
import requests

def get_elevation(lon, lat, units):
   
    try:

        # Extract latitude and longitude from the event
        latitude = lat
        longitude = lon
        units = units

        if latitude is None or longitude is None:
            return {
                "statusCode": 400,
                "body": {"error": "Latitude and longitude must be provided."}
            }
        if units != 'feet' and units != 'meters':
            return {
                "statusCode": 400,
                "body": {"error": "Units must be 'feet' or 'meters'."}
            }

        # API URL and parameters
        api_url = 'https://epqs.nationalmap.gov/v1/json'
        params = {
            "x": longitude,
            "y": latitude,
            "units": units,
            "wkid": 4326
        }

        # Call the API
        response = requests.get(api_url, params=params)
        response.raise_for_status()  # Raise HTTPError for bad responses (4xx and 5xx)

        # Parse the response
        data = response.json()
        # Extract the elevation value
        elevation = data.get("value")
        # print(elevation)
        if elevation is not None:
            resp = {"status": "success",
                    "elevation": {
                    "latitude": latitude,
                    "longitude": longitude,
                    "elevation": elevation,
                    "units": units
                }}
            return {
                "statusCode": 200,
                 "headers": {
                        "Content-Type": "application/json"
                },
                "body": resp
                 }
        
        else:
            return {
                "statusCode": 500,
                "body": {"error": "Unable to retrieve elevation data."}
            }

    except requests.exceptions.RequestException as e:
        return {
            "statusCode": 500,
            "body": {"error": str(e)}
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": {"error": str(e)}
        }
           
def lambda_handler(event, context):
    # Scott Newby
    # Steampunk
    # 2025.02.11
    # Reconfiguration after networking re-established
    # Get the elevation for a point (centroid of a land area)
    
    # Get the parameters from the calling system
    slat = event.get("lat")
    slng = event.get("lng")
    sUnit = event.get("units")
    # Call the elevation function
    ret = get_elevation(slng,slat,sUnit)
    # print(ret)
    # return the elevation response data
    return ret


