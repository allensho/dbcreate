import json
import psycopg2
import boto3
import os
import time

# Initialize the S3 client
s3 = boto3.client('s3')

def get_secret():
    secret_name = "lakehousedb3"
    region_name = "us-east-1"

    client = boto3.client("secretsmanager", region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)

    # Parse the secret string
    secret = json.loads(response["SecretString"])
    return secret

# write file to track the latest raster date in the system
def write_file_to_qt_zne(file_nm, file_content):

    try:

        s3.put_object(
            Bucket="quarantine-zone-stmpnk",
            Key=f"raw_gis_rasters_error/{file_nm}",
            Body=file_content
        )
        print('COMPLETED - write_file_to_qt_zne function completd for {file_nm}')
    except Exception as error:
        print('ERROR - write_file_to_qt_zne function failed with {error}')
        return {
            "statusCode": 500,
            "body": f"Error writing quarantine file to S3: {str(error)}"
        }
# write file to track the latest raster date in the system
def write_max_raster_dt(obj_key):
    
    try:
        dt_str = obj_key[-12:][:8][:4] + "-" + obj_key[-12:][:8][4:][:2] + "-" + obj_key[-12:][:8][4:][2:]

        s3.put_object(
            Bucket='landing-zone-stmpnk',
            Key='gis-raw-raster/max_raster_dt.txt',
            Body=dt_str
        )
        print('COMPLETED - write_max_raster_dt function completed')
        return dt_str
    except Exception as error:
        print('ERROR - write_max_raster_dt function failed with {error}')
        return {
            "statusCode": 500,
            "body": f"Error writing max_raster_dt file to S3: {str(error)}"
        }

def dq_check_num_rasters(file_content, secret):
    Connection = None
    iret = None
    try:

        # Connect to PostgreSQL
        connection = psycopg2.connect(
            host=secret["host"],
            database=secret["dbname"],
            user=secret["username"],
            password=secret["password"],
            port=secret["port"]
        )
        
        cursor = connection.cursor()
        
        # SQL query to insert the file (as BYTEA) into the table
        insert_query = """
            SELECT ref_climate.fnct_dq_raster_num_bands(%s)
        """
        # Execute the query
        cursor.execute(insert_query, (psycopg2.Binary(file_content),))
        iret = cursor.fetchone()[0]

        print(f"COMPLETED - dq_check_num_rasters completed & found {iret} bands")
    except Exception as error:
        print(f"ERROR - dq_check_num_rasters failed with {error}")
        raise

    finally:
        # Close the database connection
        if connection:
            cursor.close()
            connection.close()
        return iret

def fnct_load_landarea_fact(date_str,secret):
    Connection = None
    iret = None
    try:

        # Connect to PostgreSQL
        connection = psycopg2.connect(
            host=secret["host"],
            database=secret["dbname"],
            user=secret["username"],
            password=secret["password"],
            port=secret["port"]
        )
        
        cursor = connection.cursor()
        
        # SQL query to insert the file (as BYTEA) into the table
        funct_query = """
            SELECT star_schema.fnct_load_daily_landareas(%s)
        """
        # sleep to allow for rasters to generate
        # TODO put the trigger logic into a funciton definition here - SKN 2025-02-19
        time.sleep(40)
        # run the command for loading the fact based on the date of the file loaded
        # Execute the query
        cursor.execute(funct_query, (date_str,))
         # Commit the transaction
        connection.commit()
        print(f"COMPLETED - fnct_load_daily_landareas")

    except Exception as error:
        print(f"ERROR - fnct_load_landarea_fact {error}")
        raise

    finally:
        # Close the database connection
        if connection:
            cursor.close()
            connection.close()

def store_file_in_postgres(object_key, file_content, secret):
    Connection = None
    try:

        # Connect to PostgreSQL
        connection = psycopg2.connect(
            host=secret["host"],
            database=secret["dbname"],
            user=secret["username"],
            password=secret["password"],
            port=secret["port"]
        )
        
        cursor = connection.cursor()
        
        # SQL query to insert the file (as BYTEA) into the table
        insert_query = """
            INSERT INTO ref_climate.geotiff_blobs (blob_data, file_name)
            VALUES (%s, %s)
        """
        # Execute the query
        cursor.execute(insert_query, (psycopg2.Binary(file_content), object_key))

        # Commit the transaction
        connection.commit()
        # write the max raster dt to track - change something redploy
        dstr = write_max_raster_dt(object_key)
        
        print(f"COMPLETED - store_file_in_postgres File {object_key} inserted into PostgreSQL successfully.")

        fnct_load_landarea_fact(dstr, secret)
    except Exception as error:
        print(f"ERROR - inserting file {object_key} into PostgreSQL: {error}")
        raise

    finally:
        # Close the database connection
        if connection:
            cursor.close()
            connection.close()

def lambda_handler(event, context):
    # get the secret and set values:
    # Get the secret
    scrt = get_secret()

    for record in event['Records']:
        # Get the bucket name and object key from the event
        bucket_name = record['s3']['bucket']['name']
        object_key = record['s3']['object']['key']

        # Get the file
        response = s3.get_object(Bucket=bucket_name, Key=object_key)
        # read the response
        file_content = response['Body'].read()
        # check the number of rasters
        inumrast = dq_check_num_rasters(file_content, scrt)
        # do we have the correct number of rasters?
        if inumrast == 4:
            # store file in postgresql
            store_file_in_postgres(object_key, file_content, scrt)
        else:
            # lmbda_cli = boto3.client("lambda")
            sns = boto3.client("sns")
            # move raster to quarantine
            filenm = object_key.split("/")[-1]
            write_file_to_qt_zne(filenm, file_content)
            # send sns alert
            # fnct_arn = "arn:aws:lambda:us-east-1:571600842530:function:lf-common-sns"
            msg = "A GIS LH raster, " + filenm + " did not have the correct number of bands and has been copied to the quarantine zone."
            # print(msg)
            # ?ata = {"sns_arn": "arn:aws:sns:us-east-1:571600842530:gis-lh-dq", "message": msg, "subject": "GIS LH - Bad Raster Encountered"}
            
            # response = lmbda_cli.invoke(FunctionName=fnct_arn, InvocationType='RequestResponse', Payload=json.dumps(data))
            response = sns.publish(TopicArn='arn:aws:sns:us-east-1:571600842530:gis-lh-dq', Message=msg, Subject='GIS Lakehouse - Bad Raster')


