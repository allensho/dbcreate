INSERT INTO star_schema.dim_crop_type (crop_type_name,crop_type_description,crop_specific_species,created_date_utc,created_by_identifier,last_updated_date_utc,last_update_by_identifier) VALUES
	 ('Corn','A corn crop',NULL,'2024-11-19 09:36:34.654982-05','scott.newby@steampunk.com',NULL,NULL),
	 ('Soybean','a soybean crop',NULL,'2024-11-19 09:36:34.654982-05','scott.newby@steampunk.com',NULL,NULL);
