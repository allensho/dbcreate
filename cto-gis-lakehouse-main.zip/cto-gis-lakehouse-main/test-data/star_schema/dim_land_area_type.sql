INSERT INTO star_schema.dim_land_area_type (land_area_type_name,land_area_type_description,created_date_utc,last_updated_date_utc,created_by_identifier,last_updated_by_identifier) VALUES
	 ('Market Crop','A land area that is utilized for producing market crops','2024-11-19 09:18:31.838813-05',NULL,'scott.newby@steampunk.com',NULL);
