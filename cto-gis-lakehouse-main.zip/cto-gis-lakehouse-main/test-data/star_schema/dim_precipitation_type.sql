INSERT INTO star_schema.dim_precipitation_type (create_datetime_utc,last_update_datetime_utc,preciptiation_type_name,precipitation_type_description) VALUES
	 ('2024-11-19 09:25:32.423454-05',NULL,'Liquid','Precipitation that is rain/liquid in nature'),
	 ('2024-11-19 09:25:32.423454-05',NULL,'Mixed Phase','Precipitation that is mixed based on temperature'),
	 ('2024-11-19 09:25:32.423454-05',NULL,'Frozen','Precipitation that is frozen based on temperature');
