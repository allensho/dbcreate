INSERT INTO star_schema.dim_event_type (event_type_name,event_type_description,created_date_utc,created_by_identifier,last_updated_date_utc,last_update_by_identifier) VALUES
	 ('Daily Climate','Daily Climate Record Tracking','2025-02-13 14:12:24.567332-05','scott.newby@steampunk.com',NULL,NULL);
